package com.anuj.onlineShop.service;

import com.anuj.onlineShop.model.Customer;

public interface CustomerService {
	void addCustomer(Customer customer);

	Customer getCustomerByUserName(String userName);
}
