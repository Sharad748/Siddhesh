package com.anuj.onlineShop.service;

import com.anuj.onlineShop.model.SalesOrder;

public interface SalesOrderService {
	void addSalesOrder(SalesOrder salesOrder);
}
