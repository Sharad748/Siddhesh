package com.anuj.onlineShop.service;

import com.anuj.onlineShop.model.Cart;

public interface CartService {
    Cart getCartById(int CartId);
}

