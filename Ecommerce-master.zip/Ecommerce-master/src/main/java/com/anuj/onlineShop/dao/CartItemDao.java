package com.anuj.onlineShop.dao;

import com.anuj.onlineShop.model.Cart;
import com.anuj.onlineShop.model.CartItem;

public interface CartItemDao {
    void addCartItem(CartItem cartItem);
    
    void removeCartItem(int CartItemId);
    
    void removeAllCartItems(Cart cart);
}

