package com.anuj.emart.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="PRODUCT_CATELOGUE", schema = "anujtestdbnew")
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

    @NotNull(message = "Product name is required.")
    @Basic(optional = false)
    @Column(name="PROD_NAME")
    private String name;
    
    @NotNull(message = "Product price is required.")
    @Column(name="PROD_PRICE")
    private Double price;

    @Column(name="PROD_DESCRIPTION")
    private String description;
    
    @Column(name="category")
    private String category;
    
    

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Product(int id, @NotNull(message = "Product name is required.") String name,
			@NotNull(message = "Product price is required.") Double price, String description) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.description = description;
	}

	public Product() {
		super();
	}
    
}
