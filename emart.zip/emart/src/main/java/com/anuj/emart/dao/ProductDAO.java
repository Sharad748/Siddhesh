package com.anuj.emart.dao;

import java.util.List;
import com.anuj.emart.entity.Product;


public interface ProductDAO {

	public List<Product> getProducts();

	public void saveProduct(Product theCustomer);

	public Product getProduct(int theId);

	public void deleteProduct(int theId);
	
}
