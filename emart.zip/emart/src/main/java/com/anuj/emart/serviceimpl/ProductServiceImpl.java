package com.anuj.emart.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.anuj.emart.dao.ProductDAO;
import com.anuj.emart.entity.Product;
import com.anuj.emart.service.ProductService;


@Service
public class ProductServiceImpl implements ProductService {

	// need to inject customer dao
	@Autowired
	private ProductDAO productDAO;

	@Override
	@Transactional
	public List<Product> getProducts() {
		// TODO Auto-generated method stub
		return productDAO.getProducts();
	}

	@Override
	@Transactional
	public void saveProduc(Product theCustomer) {
		// TODO Auto-generated method stub
		productDAO.saveProduct(theCustomer);
	}

	@Override
	@Transactional
	public Product getProduct(int theId) {
		// TODO Auto-generated method stub
		return productDAO.getProduct(theId);
	}

	@Override
	@Transactional
	public void deleteProduct(int theId) {
		// TODO Auto-generated method stub
		productDAO.deleteProduct(theId);
	}
}





