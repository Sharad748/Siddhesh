package com.anuj.emart.service;

import java.util.List;

import com.anuj.emart.entity.Product;


public interface ProductService {

	public List<Product> getProducts();

	public void saveProduc(Product theCustomer);

	public Product getProduct(int theId);

	public void deleteProduct(int theId);
	
}
